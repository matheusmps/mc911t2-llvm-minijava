package llvmast;
public class LlvmCloseDefinition extends LlvmInstruction{
    public String toString(){
	return "}";
    }

}