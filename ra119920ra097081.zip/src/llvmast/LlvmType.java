package llvmast;
public abstract class LlvmType{}