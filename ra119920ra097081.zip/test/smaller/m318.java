// testando operador < (OK)
class m318
{
   public static void main(String[] args)
   {
       if ( 10 < 20 )
          System.out.println(1);
   }
}