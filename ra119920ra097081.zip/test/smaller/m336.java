// testando this (OK)
class m336
{
   public static void main(String[] args)
   {
      System.out.println(new a().i());
   }
}

class a
{
   public a A(){return this;}
   public int i(){ return 0; }
}