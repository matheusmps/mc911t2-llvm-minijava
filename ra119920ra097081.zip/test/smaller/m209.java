// heranca entre duas classes (OK)
class m209
{
    public static void main(String[] args)
    {
    	System.out.println(10);
    }
}

class a extends b
{
   public int i() { return 1; }
}

class b
{
   public int i() { return 0; }
}