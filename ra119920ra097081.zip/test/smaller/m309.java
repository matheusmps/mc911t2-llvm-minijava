// testando operador + (OK)
class m309
{
   public static void main(String[] args)
   {
       System.out.println(10 + 1);
   }
}