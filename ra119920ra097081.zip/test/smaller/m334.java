// testando operador ! (OK)
class m334
{
   public static void main(String[] args)
   {
       if ( !false )
          System.out.println(1);
   }
}