// herdando da classe principal (OK)
class m211
{
    public static void main(String[] args)
    {
    	System.out.println(10);
    }
}

class a extends m211
{
}
