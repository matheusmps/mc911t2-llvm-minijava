// testando operador && (OK)
class m322
{
   public static void main(String[] args)
   {
       if ( true && true )
          System.out.println(1);
   }
}