// atributo e local com mesmo nome(OK)
class m110
{
    public static void main(String[] args)
    {
    	System.out.println(10);
    }
}

class c
{
	int p;
	public int i(){int p; return 0;}
}
