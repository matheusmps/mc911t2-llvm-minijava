// testando new array (OK)
class m330
{
   public static void main(String[] args)
   {
      System.out.println(0);
   }
}

class a
{
   int[] i;
   public int i(){i = new int[10]; return 0;}
}